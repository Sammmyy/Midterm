//AIzaSyBAsHquxUSHSwezK0HLXDJs9j4jLVBlrks
 //https://www.googleapis.com/youtube/v3/?id=7lCDEYXw3mM&key=AIzaSyBAsHquxUSHSwezK0HLXDJs9j4jLVBlrks
let hiphopcontainer = document.querySelector("#hiphopvideos")


sendApiRequest()
 function sendApiRequest(){
  fetch(" https://www.googleapis.com/youtube/v3/search?key=AIzaSyBAsHquxUSHSwezK0HLXDJs9j4jLVBlrks&channelId=UC0BletW9phE4xHFM44q4qKA&part=snippet,id&order=date&maxResults=20")
  .then(function(data){
    return data.json();
  })
  .then(function(json){
    console.log (json);
    extractid(json)
  });
};
function extractid(data){
  let vidid1 = data.items[0].id.videoId
  console.log(vidid1)
  let vidid2 = data.items[1].id.videoId
  console.log(vidid2)
  let vidid3 = data.items[2].id.videoId
  console.log(vidid3)
  let vidid4 = data.items[3].id.videoId
  console.log(vidid4)
  let vidid5 = data.items[4].id.videoId
  console.log(vidid5)
  createVideos(vidid1, vidid2, vidid3, vidid4, vidid5)
}


function createVideos(a,b,c,d,e){
 hiphopcontainer.innerHTML = "<iframe width='100%' height='315' src='https://www.youtube.com/embed/"+a+"' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>" + "<iframe width='100%' height='315' src='https://www.youtube.com/embed/"+b+"' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>"+"<iframe width='100%' height='315' src='https://www.youtube.com/embed/"+c+"' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>" + "<iframe width='100%' height='315' src='https://www.youtube.com/embed/"+d+"' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>"+ "<iframe width='100%' height='315' src='https://www.youtube.com/embed/"+e+"' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>"


}