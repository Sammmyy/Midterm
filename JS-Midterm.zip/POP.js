let popcontainer = document.querySelector("#popvideos")


sendApiRequest()
 function sendApiRequest(){
  fetch(" https://www.googleapis.com/youtube/v3/search?key=AIzaSyBAsHquxUSHSwezK0HLXDJs9j4jLVBlrks&channelId=UC9CoOnJkIBMdeijd9qYoT_g&part=snippet,id&order=date&maxResults=20")
  .then(function(data){
    return data.json();
  })
  .then(function(json){
    console.log (json);
    extractid(json)
  });
};
function extractid(data){
  let vidid1 = data.items[0].id.videoId
  console.log(vidid1)
  let vidid2 = data.items[1].id.videoId
  console.log(vidid2)
  let vidid3 = data.items[2].id.videoId
  console.log(vidid3)
  let vidid4 = data.items[3].id.videoId
  console.log(vidid4)
  let vidid5 = data.items[4].id.videoId
  console.log(vidid5)
  createVideos(vidid1, vidid2, vidid3, vidid4, vidid5)
}


function createVideos(a,b,c,d,e){
 popcontainer.innerHTML = "<iframe width='560' height='315' src='https://www.youtube.com/embed/"+a+" 'iS1g8G_njx8' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>" + "<iframe width='560' height='315' src='https://www.youtube.com/embed/"+b+" 'iS1g8G_njx8' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>" + "<iframe width='560' height='315' src='https://www.youtube.com/embed/"+c+" 'iS1g8G_njx8' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>" + "<iframe width='560' height='315' src='https://www.youtube.com/embed/"+d+" 'iS1g8G_njx8' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>" + "<iframe width='560' height='315' src='https://www.youtube.com/embed/"+e+" 'iS1g8G_njx8' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>"
}